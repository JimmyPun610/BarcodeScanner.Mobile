﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using BarcodeScanner.XF;
using Foundation;
using GoogleVisionBarCodeScanner.iOS.Renderer;
using UIKit;
using Xamarin.Forms;
using Xamarin.Forms.Platform.iOS;
[assembly: ExportRenderer(typeof(BarcodeScanningPage), typeof(BarcodeScanningPageRenderer))]
namespace GoogleVisionBarCodeScanner.iOS.Renderer
{
    public class BarcodeScanningPageRenderer : PageRenderer
    {
       
        UIButton CancelButton;
        UIButton FlashlightButton;
        
        public override void ViewDidLoad()
        {
            base.ViewDidLoad();
            var view = NativeView;
            view.BackgroundColor = UIColor.White;
            Xamarin.Essentials.DisplayInfo DisplayInfo = Xamarin.Essentials.DeviceDisplay.MainDisplayInfo;
            CancelButton = UIButton.FromType(UIButtonType.System);
            CancelButton.Frame = new CoreGraphics.CGRect(0, 0, DisplayInfo.Width / DisplayInfo.Density / 4, 60);
            CancelButton.SetTitleColor(UIColor.White, UIControlState.Normal);
            CancelButton.BackgroundColor = UIColor.FromRGB(255, 0, 0);
            view.AddSubview(CancelButton);

            FlashlightButton = UIButton.FromType(UIButtonType.System);
            FlashlightButton.Frame = new CoreGraphics.CGRect(0, 0, DisplayInfo.Width / DisplayInfo.Density / 4, 60);
            FlashlightButton.SetTitleColor(UIColor.White, UIControlState.Normal);
            FlashlightButton.BackgroundColor = UIColor.FromRGB(0, 75, 255);
            view.AddSubview(FlashlightButton);
        }
        protected override void OnElementChanged(VisualElementChangedEventArgs e)
        {
            base.OnElementChanged(e);
            if (e.OldElement != null || Element == null)
            {
                return;
            }
            var page = e.NewElement as BarcodeScanningPage;
            CancelButton.SetTitle(page.CancelText, UIControlState.Normal);
            FlashlightButton.SetTitle(page.FlashlightMessage, UIControlState.Normal);
        }
    }
}